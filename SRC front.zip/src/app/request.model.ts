export interface Request {
    typeRequest: string;
    title: string;
    description: string;
    status: string;
  }
  