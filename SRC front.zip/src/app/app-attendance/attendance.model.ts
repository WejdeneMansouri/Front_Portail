export interface Attendance {
    id: number;
    date: string;
    checkInTime: Date | string;
    checkOutTime: Date | string | null;
  }
  