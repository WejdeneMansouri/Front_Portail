declare module '*.scss' {
    const content: string;
    export default content;
  }