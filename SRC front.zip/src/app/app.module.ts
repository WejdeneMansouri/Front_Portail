import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router'; // Import RouterModule for routing
import { FormsModule } from '@angular/forms'; // Import FormsModule if needed
import { HttpClientModule } from '@angular/common/http'; // Import HttpClientModule if needed
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard.component'; // Import DashboardComponent
import { AppRoutingModule } from './app-routing.module';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { HrDashboardComponent } from './hr-dashboard/hr-dashboard.component';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { LoginComponent } from './login/login.component';
import { LeaveRequestComponent } from './requests/leave-request/leave-request.component';
import { LoanRequestComponent } from './requests/loan-request/loan-request.component';
import { AuthRequestComponent } from './requests/auth-request/auth-request.component';
import { DocumentRequestComponent } from './requests/document-request/document-request.component';
import { PersonalSituationRequestComponent } from './requests/personal-situation/personal-situation.component';
import { ProfileComponent } from './profile/profile.component';
import { UserRequestsComponent } from './user-requests/user-requests.component';
import { UsersListComponent } from './users-list/users-list.component';
import { AttendanceComponent } from './app-attendance/app-attendance.component';
import { PostListComponent } from './post/post-list/post-list.component';
import { CreatePostComponent } from './post/create-post/create-post.component';
import { HomeComponent } from './home/home.component';



@NgModule({
  declarations: [
    DashboardComponent,
    AppComponent,
    LoginComponent,
    AdminDashboardComponent,
    HrDashboardComponent,
    EmployeeDashboardComponent,
    LeaveRequestComponent,
    LoanRequestComponent,
    AuthRequestComponent,
    DocumentRequestComponent,
    PersonalSituationRequestComponent,
    ProfileComponent,
    UserRequestsComponent,
    UserRequestsComponent,
    UsersListComponent,
    AttendanceComponent,
    PostListComponent,
    CreatePostComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([]), // Configure routes here
    FormsModule, // Include FormsModule if using ngModel in forms
    HttpClientModule, // Include HttpClientModule for making HTTP requests
    AppRoutingModule // Import AppRoutingModule

  ],
  providers: [ApiService,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
