import { Component, EventEmitter, Output } from '@angular/core';
import { PostService } from '../post.service';
import { Post } from '../post.model';

@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.scss']
})
export class CreatePostComponent {
  @Output() newPost = new EventEmitter<Post>();
  message: string = ''; // Variable pour stocker le message à afficher

  post: Post = {
    title: '',
    subject: '',
    imageUrl: ''
  };

  constructor(private postService: PostService) {}

  submitPost(): void {
    this.postService.addPost(this.post).subscribe(
      post => {
        // En cas de succès
        this.message = 'Annonce enregistrée avec succès!';
        this.newPost.emit(post);
        this.post = { title: '', subject: '', imageUrl: '' }; // Réinitialiser le formulaire après enregistrement
      },
      error => {
        // En cas d'erreur
        console.error('Error submitting post:', error);
        this.message = 'Erreur lors de l\'enregistrement de l\'annonce.';
      }
    );
  }
}
