import { Component } from '@angular/core';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-personal-situation',
  templateUrl: './personal-situation.component.html',
  styleUrls: ['./personal-situation.component.scss']
})
export class PersonalSituationRequestComponent {
  personalSituationRequest: any = {
    title: '',
    details: '',
    requestType: '',
    status: 'Pending' // Default status set to 'Pending'

  };
  requestStatus: string | null = null; // Variable to store request status

  constructor(private apiService: ApiService, private router: Router) {}

  submitPersonalSituationRequest(): void {
    if (this.isValidRequest()) {
      this.apiService.createPersonalSituationRequest(this.personalSituationRequest).subscribe(
        (response) => {
          console.log('Personal situation request created successfully:', response);
          this.requestStatus = 'Demande envoyer'; // Set success message

          this.router.navigate(['/employee']);
        },
        (error) => {
          console.error('Error creating personal situation request:', error);
          // Handle error (e.g., display error message to user)
        }
      );
    } else {
      console.error('Invalid request. Please fill in all required fields.');
      // Display error message to user or handle it accordingly
    }
  }

  isValidRequest(): boolean {
    // Check if all required fields are filled
    return this.personalSituationRequest.title && this.personalSituationRequest.details && this.personalSituationRequest.requestType;
  }
}
